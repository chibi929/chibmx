# sss-190206

This project is for internal seminars to be held on February 6, 2019.
Copied from [sss/180829](../180829).

## Directory structure

```bash
$ tree . -L 2
.
├── README.md
├── step1
│   ├── index.js
│   ├── node_modules
│   ├── package-lock.json
│   ├── package.json
│   └── upload.zip
├── step2
│   ├── index.js
│   ├── node_modules
│   ├── package-lock.json
│   ├── package.json
│   └── upload.zip
└── step3
    ├── index.js
    ├── node_modules
    ├── package-lock.json
    ├── package.json
    └── upload.zip
```
